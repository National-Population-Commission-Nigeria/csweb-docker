<?php
$rewriteSuccess = true;

require_once __DIR__ .'/prereqs.php';

?>
