<?php
$loader = require_once __DIR__ .'/../app/bootstrap.php';
$loader->registerNamespace('CSPro\\Tests', __DIR__);