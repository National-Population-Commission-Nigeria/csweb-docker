<?php
define('API_VERSION', '2.0'); // REST API version, incremented when REST endpoints/arguments changes
define('SCHEMA_VERSION', 6); // Database schema version, incremented when database tables change ) (no change from 7.5 to 7.6)
define('CSPRO_VERSION', '7.7.0')
?>
