<?php
namespace AppBundle\CSPro;
class SyncHistoryEntry
{	
	public $revisionNumber;
	public $device;
	public $dictionary;
	public $universe;
	public $direction;
	public $dateTime;
}
